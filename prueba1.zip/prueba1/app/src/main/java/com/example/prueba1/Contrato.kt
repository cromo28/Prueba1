package com.example.prueba1.ui.contrato

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.prueba1.R


class Contrato : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contrato)

        val editHoras = findViewById<EditText>(R.id.editHoras)
        val editPagoHora = findViewById<EditText>(R.id.editPagoHora)
        val buttonCalcular = findViewById<Button>(R.id.buttonCalcular)
        val textResultado = findViewById<TextView>(R.id.textViewPagoNeto)

        buttonCalcular.setOnClickListener {
            try {
                val horas = editHoras.text.toString().toFloatOrNull() ?: 0f
                val pagoHora = editPagoHora.text.toString().toFloatOrNull() ?: 0f
                val pagoBruto = horas * pagoHora
                val pagoNeto = pagoBruto * (1 * 0.20f) // Aplica retencion  20%
                textResultado.text = "Pago Neto: $%.2f".format(pagoNeto)
            } catch (e: Exception) {
                textResultado.text = "Error en el cálculo"
            }
        }

        val buttonVolver = findViewById<Button>(R.id.buttonVolver)
        buttonVolver.setOnClickListener {
            volverAPrincipal(it)
        }
    }

    fun volverAPrincipal(view: View) {
        finish()
    }
}
