package com.example.prueba1
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.prueba1.ui.theme.Prueba1Theme
import android.content.Intent
import androidx.activity.compose.setContent
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat.startActivity
import com.example.prueba1.ui.contrato.Contrato
import com.example.prueba1.ui.honorarios.honorarios


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainScreen()
        }
    }
}

@Composable
fun MainScreen() {
    val context = LocalContext.current
    Button(onClick = {
        val intent = Intent(context, honorarios::class.java)
        context.startActivity(intent)
    }) {
        Text("Calculadora Honorarios")
    }

    Button(onClick = {
        val intent = Intent(context, Contrato::class.java)
        context.startActivity(intent)
    }) {
        Text("Calculadora Contrato")
    }
}
