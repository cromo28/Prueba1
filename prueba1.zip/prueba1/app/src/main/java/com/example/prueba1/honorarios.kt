package com.example.prueba1.ui.honorarios

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
class honorarios : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HonorariosScreen {
                finish()
            }
        }
    }
}

@Composable
fun HonorariosScreen(onBack: () -> Unit) {
    var horasTrabajadas by remember { mutableStateOf("") }
    var pagoPorHora by remember { mutableStateOf("") }
    var pagoNeto by remember { mutableStateOf(0.0f) }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = horasTrabajadas,
            onValueChange = { horasTrabajadas = it },
            label = { Text("Horas Trabajadas") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = pagoPorHora,
            onValueChange = { pagoPorHora = it },
            label = { Text("Pago por Hora") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                val horas = horasTrabajadas.toFloatOrNull() ?: 0f
                val pagoHora = pagoPorHora.toFloatOrNull() ?: 0f
                val pagoBruto = horas * pagoHora
                pagoNeto = pagoBruto * (1 * 0.13f) //Aplica retención  13%
            },
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text("Calcular Pago Neto")
        }

        Text("Pago Neto: $pagoNeto", modifier = Modifier.padding(top = 16.dp))

        Button(
            onClick = onBack,
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text("Volver a la pantalla principal")
        }
    }
}
