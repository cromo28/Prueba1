package com.example.prueba1

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import com.example.prueba1.ui.honorarios.honorarios
import com.example.prueba1.ui.contrato.Contrato

class ActivityMain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnHonorarios = findViewById<Button>(R.id.btnHonorarios)
        val btnContrato = findViewById<Button>(R.id.btnContrato)

        btnHonorarios.setOnClickListener {
            val intent = Intent(this, honorarios::class.java)
            startActivity(intent)
        }

        btnContrato.setOnClickListener {
            val intent = Intent(this, Contrato::class.java)
            startActivity(intent)
        }
    }
}
